package com.example.panta.farmakio_client;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Cart extends MainActivity {

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private ListView lvCart;
    private CartListAdapter adapter;
    private List<Product> mCartList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(Global.a==true)
           setContentView(R.layout.activity_cart);
        else if(Global.a==false)
            setContentView(R.layout.activity_cart_eng);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView =  findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        lvCart = (ListView)findViewById(R.id.listview_cart);

        mCartList = new ArrayList<>();
        //Add sample data for list
        //We can get data from DB, webservice here
        mCartList.add(new Product(1,"Panadol Extra", 4, 1 , "Description of the Product !!!",R.drawable.panadol_extra));
        mCartList.add(new Product(2,"Panadol", 5, 2 , "Description of the Product !!!",R.drawable.panadol));
        mCartList.add(new Product(3,"Nurofen Cold and Flu", 6, 1 , "Description of the Product !!!",R.drawable.nurofen));
        mCartList.add(new Product(4,"Instaret", 4, 3 , "Description of the Product !!!",R.drawable.instaret));


        adapter = new CartListAdapter(getApplicationContext(), mCartList);
        lvCart.setAdapter(adapter);

        TextView tvtotal = findViewById(R.id.totalPrice);
        int sum=0;
        for(int i=0;i<mCartList.size();i++){
            sum=sum+(mCartList.get(i).getPrice()*mCartList.get(i).getQuantity());
        }
        tvtotal.setText(sum+"€");

    }
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.home_page:
                Intent intent_home = new Intent(getApplicationContext(),MainActivity.class);
                this.finish();
                startActivity(intent_home);
                Toast.makeText(this,"Home Page !!",Toast.LENGTH_SHORT).show();
                break;
            case R.id.calendar:
                Intent intent_calendar = new Intent(getApplicationContext(),CalendarActivity.class);
                this.finish();
                startActivity(intent_calendar);
                Toast.makeText(this,"Calendar",Toast.LENGTH_SHORT).show();
                break;
            case R.id.product:
                Intent intent_product = new Intent(getApplicationContext(),ProductActivity.class);
                this.finish();
                startActivity(intent_product);
                Toast.makeText(this,"Products",Toast.LENGTH_SHORT).show();
                break;
            case R.id.services:
                Intent intent_services= new Intent(getApplicationContext(),ServicesActivity.class);
                this.finish();
                startActivity(intent_services);
                Toast.makeText(this,"Services",Toast.LENGTH_SHORT).show();
                break;
            case R.id.communication:
                Intent intent_contact= new Intent(getApplicationContext(),ActivityContact.class);
                this.finish();
                startActivity(intent_contact);
                Toast.makeText(this,"Communication",Toast.LENGTH_SHORT).show();
                break;
            case R.id.chat:
                Intent intent_chat= new Intent(getApplicationContext(),ChatActivity.class);
                this.finish();
                startActivity(intent_chat);
                Toast.makeText(this,"Chat",Toast.LENGTH_SHORT).show();
                break;
            case R.id.overnight_pharmacies:
                Intent intent_on= new Intent(getApplicationContext(),ActivityOvernight.class);
                this.finish();
                startActivity(intent_on);

                Toast.makeText(this,"Overnight Pharmacies",Toast.LENGTH_SHORT).show();
                break;

        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }
        switch(item.getItemId()){
            case R.id.cart:
                Toast.makeText(this,"Cart",Toast.LENGTH_SHORT).show();

                break;
            case R.id.action_account:
                Toast.makeText(this,"Account",Toast.LENGTH_SHORT).show();

                AlertDialog.Builder mBuilder = new AlertDialog.Builder(Cart.this);
                View mView = getLayoutInflater().inflate(R.layout.activity_log_in, null);
                Button mLogin =  mView.findViewById(R.id.btnLogin);

                mLogin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(Global.a==true) {
                            Toast.makeText(Cart.this, "Έχετε μπει στο λογαριασμό σας", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(Cart.this,"You have login your account",Toast.LENGTH_SHORT).show();
                        }
                        Intent intent_profile = new Intent(getApplicationContext(),Profile.class);
                        startActivity(intent_profile);
                    }
                });

                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();

                // this.finish();

                break;
            case R.id.action_language:
                Toast.makeText(this,"Language",Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void confirmOrder(View v){
        AlertDialog.Builder builder = new AlertDialog.Builder(Cart.this);

if (Global.a==true) {
    builder.setMessage("Θέλετε να ολοκληρώσετε την παρσγγελία σας;")
            .setPositiveButton("Ναι", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent_Home = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent_Home);

                }
            })
            .setNegativeButton("Οχι", null);
}else if(Global.a==false)
{
    builder.setMessage("Would you like to complete your order?")
            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent_Home = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent_Home);

                }
            })
            .setNegativeButton("No", null);
}
        AlertDialog alert = builder.create();
        alert.show();
    }

}
