package com.example.panta.farmakio_client;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class AddProduct extends AppCompatActivity {
    ImageView iv;
    TextView tvname;
    TextView tvprice;
    String[] array;
    int[] image_price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(Global.a==true)
            setContentView(R.layout.activity_add_product);
        else if(Global.a==false)
            setContentView(R.layout.activity_add_product_eng);

        iv = findViewById(R.id.added_pruduct_image);
         tvname = findViewById(R.id.added_pruduct_Name);
         tvprice = findViewById(R.id.price);


        Intent intent_input_Product = getIntent();
        array = intent_input_Product.getStringArrayExtra("PRODUCT INFO");
        image_price = intent_input_Product.getIntArrayExtra("PRODUCT IMAGE_PRICE");



        iv.setImageResource(image_price[0]);
        tvprice.setText(image_price[1]+"€");
        tvname.setText(array[0]+"");



    }
    public void increment(View v){
        TextView quantity_tv = findViewById(R.id.quantityTextView);
        int qua = Integer.parseInt(quantity_tv.getText().toString());
        qua++;
        tvprice.setText((qua*image_price[1])+"€");
        quantity_tv.setText(qua+"");
    }
    public void decrement(View v){
        TextView quantity_tv = findViewById(R.id.quantityTextView);
        int qua = Integer.parseInt(quantity_tv.getText().toString());
        if(qua==1){
            return;
        }
        qua--;
        tvprice.setText((image_price[1]*qua)+"€");
        quantity_tv.setText(qua+"");
    }
    public void addToCart(View v){

        AlertDialog.Builder builder = new AlertDialog.Builder(AddProduct.this);

        if(Global.a==true) {
            builder.setMessage("Θέλετε να δείτε το καλάθι σας;")
                    .setPositiveButton("Ναι", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(), Cart.class);
                            startActivity(intent_Cart);
                        }
                    })
                    .setNegativeButton("Συνεχιστε την Περιηγηση", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Product = new Intent(getApplicationContext(), Product.class);
                            startActivity(intent_Product);
                        }
                    });
        }

        else if(Global.a==false){
            builder.setMessage("Would you like to see your cart?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(),Cart.class);
                            startActivity(intent_Cart);
                        }
                    })
                    .setNegativeButton("Continue Shopping",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Product = new Intent(getApplicationContext(),Product.class);
                            startActivity(intent_Product);
                        }
                    });

        }


                AlertDialog alert = builder.create();
                alert.show();
                if(Global.a==true)
        Toast.makeText(this,"Το προιόν έχει προστεθεί στο καλάθι σας.",Toast.LENGTH_SHORT).show();
                else if(Global.a==false)
        Toast.makeText(this,"The Item has been added to your Cart",Toast.LENGTH_SHORT).show();

    }
}
