package com.example.panta.farmakio_client;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class CalendarActivity extends MainActivity {
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private Button appointmentPhase1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(Global.a==true)
        setContentView(R.layout.activity_calendar);
       else if(Global.a==false)
            setContentView(R.layout.activity_calendar_eng);


        appointmentPhase1=(Button)findViewById(R.id.appointment);
        appointmentPhase1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAppointmentPhase1();
            }
        });


        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView =  findViewById(R.id.nav_view);
       navigationView.setNavigationItemSelectedListener(this);
    }

    public void openAppointmentPhase1(){
        Intent intent = new Intent(this, com.example.panta.farmakio_client.appointmentPhase1.class);
        startActivity(intent);
    }

    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.home_page:
                Intent intent_home = new Intent(getApplicationContext(),MainActivity.class);
                this.finish();
                startActivity(intent_home);
                Toast.makeText(this,"Home Page !!",Toast.LENGTH_SHORT).show();
                break;
            case R.id.calendar:
                Toast.makeText(this,"Calendar",Toast.LENGTH_SHORT).show();
                break;
            case R.id.product:
                Intent intent_product = new Intent(getApplicationContext(),ProductActivity.class);
                this.finish();
                startActivity(intent_product);
                Toast.makeText(this,"Products",Toast.LENGTH_SHORT).show();
                break;
            case R.id.services:
                Intent intent_services= new Intent(getApplicationContext(),ServicesActivity.class);
                this.finish();
                startActivity(intent_services);
                Toast.makeText(this,"Services",Toast.LENGTH_SHORT).show();
                break;
            case R.id.communication:
                Intent intent_contact= new Intent(getApplicationContext(),ActivityContact.class);
                this.finish();
                startActivity(intent_contact);
                Toast.makeText(this,"Communication",Toast.LENGTH_SHORT).show();
                break;
            case R.id.chat:
                Intent intent_chat= new Intent(getApplicationContext(),ChatActivity.class);
                this.finish();
                startActivity(intent_chat);
                Toast.makeText(this,"Chat",Toast.LENGTH_SHORT).show();
                break;
            case R.id.overnight_pharmacies:

                Intent intent_on= new Intent(getApplicationContext(),ActivityOvernight.class);
                this.finish();
                startActivity(intent_on);
                Toast.makeText(this,"Overnight Pharmacies",Toast.LENGTH_SHORT).show();
                break;

        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }
        switch(item.getItemId()){
            case R.id.cart:
                Toast.makeText(this,"Cart",Toast.LENGTH_SHORT).show();

                Intent intent_cart = new Intent(getApplicationContext(),Cart.class);
                startActivity(intent_cart);
                this.finish();

                break;
            case R.id.action_account:
                Toast.makeText(this,"Account",Toast.LENGTH_SHORT).show();
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(CalendarActivity.this);
                View mView = getLayoutInflater().inflate(R.layout.activity_log_in, null);
                Button mLogin =  mView.findViewById(R.id.btnLogin);

                mLogin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(Global.a==true) {
                            Toast.makeText(CalendarActivity.this, "Έχετε μπει στο λογαριασμό σας", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(CalendarActivity.this,"You have login your account",Toast.LENGTH_SHORT).show();
                        }
                        Intent intent_profile = new Intent(getApplicationContext(),Profile.class);
                        startActivity(intent_profile);
                    }
                });

                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();

                // this.finish();


                break;
            case R.id.action_language:
                Toast.makeText(this,"Language",Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
