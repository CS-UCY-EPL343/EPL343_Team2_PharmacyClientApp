package com.example.panta.farmakio_client;

public class Global {

    public static boolean a=true;
}
