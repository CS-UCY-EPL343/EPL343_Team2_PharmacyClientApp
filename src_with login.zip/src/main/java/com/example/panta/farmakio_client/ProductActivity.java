package com.example.panta.farmakio_client;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ProductActivity extends MainActivity {

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private ListView lvProduct;
    private ProductListAdapter adapter;
    private List<Product> mProductList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(Global.a==true)
            setContentView(R.layout.activity_product);
        else if(Global.a==false)
            setContentView(R.layout.activity_product_eng);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView =  findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        lvProduct = (ListView)findViewById(R.id.listview_product);

        mProductList = new ArrayList<>();
        //Add sample data for list
        //We can get data from DB, webservice here
        mProductList.add(new Product(1,"Panadol Extra", 4, 10 , "Description of the Product !!!",R.drawable.panadol_extra));
        mProductList.add(new Product(2,"Panadol", 5, 10 , "Description of the Product !!!",R.drawable.panadol));
        mProductList.add(new Product(3,"Nurofen Cold and Flu", 6, 12 , "Description of the Product !!!",R.drawable.nurofen));
        mProductList.add(new Product(4,"Instaret", 4, 10 , "Description of the Product !!!",R.drawable.instaret));
        mProductList.add(new Product(5,"Fractopon", 5, 10 , "Description of the Product !!!",R.drawable.fractopon));
        mProductList.add(new Product(6,"Fluimucil", 8, 10 , "Description of the Product !!!",R.drawable.fluimucil));
        mProductList.add(new Product(7,"Always", 5, 10 , "Description of the Product !!!",R.drawable.always));
        mProductList.add(new Product(7,"Biofenac", 9, 10 , "Description of the Product !!!",R.drawable.biofenac));

        adapter = new ProductListAdapter(getApplicationContext(), mProductList);
        lvProduct.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder mBuilder = new AlertDialog.Builder(ProductActivity.this);
                View mView = getLayoutInflater().inflate(R.layout.dialog, null);
                TextView title = mView.findViewById(R.id.Title);
                if(Global.a==true)
                    title.setText("Αναζήτηση Προϊόντων");
                else if(Global.a==false)
                    title.setText("Search Products");

                final EditText etchange =  mView.findViewById(R.id.EditInfo);
                if(Global.a==true)
                    etchange.setHint("Προϊόντα");
                else if(Global.a==false)
                    etchange.setHint("Products");

                etchange.setInputType(InputType.TYPE_CLASS_TEXT);
                Button btchange =  mView.findViewById(R.id.btnChange);

                if(Global.a==true)
                    btchange.setText("Αναζήτηση");
                else if(Global.a==false)
                    btchange.setText("Search");

                mBuilder.setView(mView);
                final AlertDialog dialog = mBuilder.create();
                dialog.show();

                btchange.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(Global.a==true)
                            Toast.makeText(ProductActivity.this,"Αναζητά ένα συγκεκριμένο προϊόν.",Toast.LENGTH_SHORT).show();
                        else if(Global.a==false)
                            Toast.makeText(ProductActivity.this,"Search a specific product.",Toast.LENGTH_SHORT).show();

                        dialog.cancel();
                    }
                });

            }
        });

        lvProduct.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent_add_product = new Intent(getApplicationContext(),AddProduct.class);


                intent_add_product.putExtra("PRODUCT INFO",new String[]{mProductList.get(position).getName(),mProductList.get(position).getDescription()});
                intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{mProductList.get(position).getImage(),mProductList.get(position).getPrice()});
                startActivity(intent_add_product);

                Toast.makeText(getApplicationContext(), "Clicked product id =" + view.getTag(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.home_page:
                Intent intent_home = new Intent(getApplicationContext(),MainActivity.class);
                this.finish();
                startActivity(intent_home);
                Toast.makeText(this,"Home Page !!",Toast.LENGTH_SHORT).show();
                break;
            case R.id.calendar:
                Intent intent_calendar = new Intent(getApplicationContext(),CalendarActivity.class);
                this.finish();
                startActivity(intent_calendar);
                Toast.makeText(this,"Calendar",Toast.LENGTH_SHORT).show();
                break;
            case R.id.product:

                Toast.makeText(this,"Products",Toast.LENGTH_SHORT).show();
                break;
            case R.id.services:
                Intent intent_services= new Intent(getApplicationContext(),ServicesActivity.class);
                this.finish();
                startActivity(intent_services);
                Toast.makeText(this,"Services",Toast.LENGTH_SHORT).show();
                break;
            case R.id.communication:
                Intent intent_contact= new Intent(getApplicationContext(),ActivityContact.class);
                this.finish();
                startActivity(intent_contact);
                Toast.makeText(this,"Communication",Toast.LENGTH_SHORT).show();
                break;
            case R.id.chat:
                Intent intent_chat = new Intent(getApplicationContext(),ChatActivity.class);
                this.finish();
                startActivity(intent_chat);
                Toast.makeText(this,"Chat",Toast.LENGTH_SHORT).show();
                break;
            case R.id.overnight_pharmacies:
                Intent intent_on= new Intent(getApplicationContext(),ActivityOvernight.class);
                this.finish();
                startActivity(intent_on);
                Toast.makeText(this,"Overnight Pharmacies",Toast.LENGTH_SHORT).show();
                break;

        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }
        switch(item.getItemId()){
            case R.id.cart:
                Toast.makeText(this,"Cart",Toast.LENGTH_SHORT).show();

                Intent intent_cart = new Intent(getApplicationContext(),Cart.class);
                startActivity(intent_cart);

                break;
            case R.id.action_account:
                Toast.makeText(this,"Account",Toast.LENGTH_SHORT).show();

                AlertDialog.Builder mBuilder = new AlertDialog.Builder(ProductActivity.this);
                View mView = getLayoutInflater().inflate(R.layout.activity_log_in, null);
                Button mLogin =  mView.findViewById(R.id.btnLogin);

                mLogin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(Global.a==true) {
                            Toast.makeText(ProductActivity.this, "Έχετε μπει στο λογαριασμό σας", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(ProductActivity.this,"You have login your account",Toast.LENGTH_SHORT).show();
                        }
                        Intent intent_profile = new Intent(getApplicationContext(),Profile.class);
                        startActivity(intent_profile);
                    }
                });

                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();

                // this.finish();


                break;
            case R.id.action_language:
                Toast.makeText(this,"Language",Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
