package com.example.panta.farmakio_client;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Profile extends MainActivity{

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(Global.a==true)
            setContentView(R.layout.activity_profile);
        else if(Global.a==false)
            setContentView(R.layout.activity_profile_eng);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView =  findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.home_page:
                Intent intent_home = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent_home);
                this.finish();
                Toast.makeText(this,"Home Page !!",Toast.LENGTH_SHORT).show();
                break;
            case R.id.calendar:
                Intent intent_calendar = new Intent(getApplicationContext(),CalendarActivity.class);
                this.finish();
                startActivity(intent_calendar);
                Toast.makeText(this,"Calendar",Toast.LENGTH_SHORT).show();
                break;
            case R.id.product:
                Intent intent_product = new Intent(getApplicationContext(),ProductActivity.class);
                this.finish();
                startActivity(intent_product);
                Toast.makeText(this,"Products",Toast.LENGTH_SHORT).show();
                break;
            case R.id.services:
                Intent intent_services= new Intent(getApplicationContext(),ServicesActivity.class);
                this.finish();
                startActivity(intent_services);
                Toast.makeText(this,"Services",Toast.LENGTH_SHORT).show();
                break;
            case R.id.communication:
                Intent intent_contact= new Intent(getApplicationContext(),ActivityContact.class);
                this.finish();
                startActivity(intent_contact);
                Toast.makeText(this,"Communication",Toast.LENGTH_SHORT).show();
                break;
            case R.id.chat:
                Intent intent_chat= new Intent(getApplicationContext(),ChatActivity.class);
                this.finish();
                startActivity(intent_chat);
                Toast.makeText(this,"Chat",Toast.LENGTH_SHORT).show();
                break;
            case R.id.overnight_pharmacies:

                Intent intent_on= new Intent(getApplicationContext(),ActivityOvernight.class);
                this.finish();
                startActivity(intent_on);
                Toast.makeText(this,"Overnight Pharmacies",Toast.LENGTH_SHORT).show();
                break;

        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }
        switch(item.getItemId()){
            case R.id.cart:
                Toast.makeText(this,"Cart",Toast.LENGTH_SHORT).show();

                Intent intent_cart = new Intent(getApplicationContext(),Cart.class);
                startActivity(intent_cart);
                this.finish();

                break;
            case R.id.action_account:
                Toast.makeText(this,"Account",Toast.LENGTH_SHORT).show();
                break;
            case R.id.action_language:
                Toast.makeText(this,"Language",Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    public void pastOrder1(View v){
        AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
        if(Global.a==true){
            builder.setMessage("Θέλετε να προσθέσετε αυτή την παραγγελία στο καλάθι σας;")
                    .setPositiveButton("Ναι", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(),Cart.class);
                            startActivity(intent_Cart);
                            finish();
                        }
                    })
                    .setNegativeButton("Οχι",null);}
        else if(Global.a==false) {
            builder.setMessage("Would you like to add this order to your cart?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(), Cart.class);
                            startActivity(intent_Cart);
                            finish();
                        }
                    })
                    .setNegativeButton("No", null);
        }
        AlertDialog alert = builder.create();
        alert.show();


    }
    public void pastOrder2(View v){
        AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
        if(Global.a==true) {
            builder.setMessage("Θέλετε να προσθέσετε αυτή την παραγγελία στο καλάθι σας;")
                    .setPositiveButton("Ναι", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(), Cart.class);
                            startActivity(intent_Cart);
                            finish();
                        }
                    })
                    .setNegativeButton("Οχι", null);
        }else if(Global.a==false){
            builder.setMessage("Would you like to add this order to your cart?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(), Cart.class);
                            startActivity(intent_Cart);
                            finish();
                        }
                    })
                    .setNegativeButton("No", null);
        }
        AlertDialog alert = builder.create();
        alert.show();

    }
    public void pastOrder3(View v){
        AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
        if(Global.a==true){
            builder.setMessage("Θέλετε να προσθέσετε αυτή την παραγγελία στο καλάθι σας;")
                    .setPositiveButton("Ναι", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(),Cart.class);
                            startActivity(intent_Cart);
                            finish();
                        }
                    })
                    .setNegativeButton("Οχι",null);}
        else if(Global.a==false) {
            builder.setMessage("Would you like to add this order to your cart?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(), Cart.class);
                            startActivity(intent_Cart);
                            finish();
                        }
                    })
                    .setNegativeButton("No", null);
        }

        AlertDialog alert = builder.create();
        alert.show();

    }
    public void pastOrder4(View v){
        AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
        if(Global.a==true){
            builder.setMessage("Θέλετε να προσθέσετε αυτή την παραγγελία στο καλάθι σας;")
                    .setPositiveButton("Ναι", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(),Cart.class);
                            startActivity(intent_Cart);
                            finish();
                        }
                    })
                    .setNegativeButton("Οχι",null);}
        else if(Global.a==false) {
            builder.setMessage("Would you like to add this order to your cart?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(), Cart.class);
                            startActivity(intent_Cart);
                            finish();
                        }
                    })
                    .setNegativeButton("No", null);
        }

        AlertDialog alert = builder.create();
        alert.show();

    }
    public void pastOrder5(View v){
        AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
        if(Global.a==true){
            builder.setMessage("Θέλετε να προσθέσετε αυτή την παραγγελία στο καλάθι σας;")
                    .setPositiveButton("Ναι", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(),Cart.class);
                            startActivity(intent_Cart);
                            finish();
                        }
                    })
                    .setNegativeButton("Οχι",null);}
        else if(Global.a==false) {
            builder.setMessage("Would you like to add this order to your cart?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent_Cart = new Intent(getApplicationContext(), Cart.class);
                            startActivity(intent_Cart);
                            finish();
                        }
                    })
                    .setNegativeButton("No", null);
        }

        AlertDialog alert = builder.create();
        alert.show();

    }
    public void EditEmail(View v){
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(Profile.this);
        View mView = getLayoutInflater().inflate(R.layout.dialog, null);
       TextView title = mView.findViewById(R.id.Title);
       if(Global.a==true)
        title.setText("Άλλαξε Email");
       else  title.setText("Change Email");
        final EditText etchange =  mView.findViewById(R.id.EditInfo);
        if(Global.a==true)
            etchange.setHint("Νέο Email");
        else  etchange.setHint("New Email");

        etchange.setInputType(InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS);
        Button btchange =  mView.findViewById(R.id.btnChange);
        if(Global.a==true)
            btchange.setText("ΑΛΛΑΓΗ");
        else  btchange.setText("CHANGE");

        mBuilder.setView(mView);
        final AlertDialog dialog = mBuilder.create();
        dialog.show();

        btchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tvemail = findViewById(R.id.tvEmail);
                tvemail.setText(etchange.getText().toString());
                if(Global.a==true)
                    Toast.makeText(Profile.this,"Το Email σας έχει αλλάξει.",Toast.LENGTH_SHORT).show();
                else  Toast.makeText(Profile.this,"Your Email has been changed.",Toast.LENGTH_SHORT).show();

                dialog.cancel();
            }
        });
    }
    public void EditPhone(View v){
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(Profile.this);
        View mView = getLayoutInflater().inflate(R.layout.dialog, null);
        TextView title = mView.findViewById(R.id.Title);
        if(Global.a==true)
            title.setText("Άλλαξε Τηλέφωνο");
        else  title.setText("Change Phone");

        final EditText etchange =  mView.findViewById(R.id.EditInfo);
        etchange.setHint("+357 XX XXX XXX");
        etchange.setInputType(InputType.TYPE_CLASS_PHONE);
        Button btchange =  mView.findViewById(R.id.btnChange);
        if(Global.a==true)
            btchange.setText("ΑΛΛΑΓΗ");
        else  btchange.setText("CHANGE");

        mBuilder.setView(mView);
        final AlertDialog dialog = mBuilder.create();
        dialog.show();

        btchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tvphone = findViewById(R.id.tvPhone);
                tvphone.setText(etchange.getText().toString());

                if(Global.a==true)
                    Toast.makeText(Profile.this,"Το Τηλέφωνο σας έχει αλλάξει.",Toast.LENGTH_SHORT).show();
                else  Toast.makeText(Profile.this,"Your phone has been changed.",Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        });

    }
    public void EditPass(View v){
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(Profile.this);
        View mView = getLayoutInflater().inflate(R.layout.dialog, null);
        TextView title = mView.findViewById(R.id.Title);
        if(Global.a==true)
            title.setText("Άλλαξε Κωδικό");
        else   title.setText("Change Password");

        final EditText etchange =  mView.findViewById(R.id.EditInfo);
        if(Global.a==true)
            etchange.setHint("Νέος Κωδικός");
        else    etchange.setHint("New Password");

        Button btchange =  mView.findViewById(R.id.btnChange);
        if(Global.a==true)
            btchange.setText("ΑΛΛΑΓΗ");
        else  btchange.setText("CHANGE");
        mBuilder.setView(mView);
        final AlertDialog dialog = mBuilder.create();
        dialog.show();

        btchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Global.a==true)
                    Toast.makeText(Profile.this,"Ο κωδικός σας έχει αλλάξει.",Toast.LENGTH_SHORT).show();
                else  Toast.makeText(Profile.this,"Your password has been changed.",Toast.LENGTH_SHORT).show();

                dialog.cancel();
            }
        });
    }
}
