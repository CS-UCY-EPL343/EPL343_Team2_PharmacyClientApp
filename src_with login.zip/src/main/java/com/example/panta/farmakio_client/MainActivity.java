package com.example.panta.farmakio_client;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.view.View;



public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private ImageView prosfora1,prosfora2,prosfora3,prosfora4,prosfora5,prosfora6;
    private ImageView epoxiako1,epoxiako2,epoxiako3,epoxiako4,epoxiako5,epoxiako6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(Global.a==true)
        setContentView(R.layout.activity_main);
        else if(Global.a==false)
            setContentView(R.layout.activity_main_eng);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView =  findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

       // Toolbar toolbar= findViewById(R.id.app_bar);
        prosfora1=(ImageView)findViewById(R.id.prosfora1);
        prosfora1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProsfora1();
            }
        });
        prosfora2=(ImageView)findViewById(R.id.prosfora2);
        prosfora2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProsfora2();
            }
        });
        prosfora3=(ImageView)findViewById(R.id.prosfora3);
        prosfora3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProsfora3();
            }
        });
        prosfora4=(ImageView)findViewById(R.id.prosfora4);
        prosfora4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProsfora4();
            }
        });
        prosfora5=(ImageView)findViewById(R.id.prosfora5);
        prosfora5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProsfora5();
            }
        });
        prosfora6=(ImageView)findViewById(R.id.prosfora6);
        prosfora6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProsfora6();
            }
        });

        epoxiako1=(ImageView)findViewById(R.id.epoxiako1);
        epoxiako1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEpoxiako1();
            }
        });
        epoxiako2=(ImageView)findViewById(R.id.epoxiako2);
        epoxiako2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEpoxiako2();
            }
        });
        epoxiako3=(ImageView)findViewById(R.id.epoxiako3);
        epoxiako3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEpoxiako3();
            }
        });
        epoxiako4=(ImageView)findViewById(R.id.epoxiako4);
        epoxiako4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEpoxiako4();
            }
        });
        epoxiako5=(ImageView)findViewById(R.id.epoxiako5);
        epoxiako5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEpoxiako5();
            }
        });
        epoxiako6=(ImageView)findViewById(R.id.epoxiako6);
        epoxiako6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEpoxiako6();
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.home_page:
                Toast.makeText(this,"Home Page !!",Toast.LENGTH_SHORT).show();
                break;
            case R.id.calendar:
                Intent intent_calendar = new Intent(getApplicationContext(),CalendarActivity.class);
                this.finish();
                startActivity(intent_calendar);
                Toast.makeText(this,"Calendar",Toast.LENGTH_SHORT).show();
                break;
            case R.id.product:
                Intent intent_product = new Intent(getApplicationContext(),ProductActivity.class);
                this.finish();
                startActivity(intent_product);
                Toast.makeText(this,"Products",Toast.LENGTH_SHORT).show();
                break;
            case R.id.services:
                Intent intent_services= new Intent(getApplicationContext(),ServicesActivity.class);
                this.finish();
                startActivity(intent_services);
                Toast.makeText(this,"Services",Toast.LENGTH_SHORT).show();
                break;
            case R.id.communication:
                Intent intent_contact= new Intent(getApplicationContext(),ActivityContact.class);
                this.finish();
                startActivity(intent_contact);
                Toast.makeText(this,"Communication",Toast.LENGTH_SHORT).show();
                break;
            case R.id.chat:
                Intent intent_chat= new Intent(getApplicationContext(),ChatActivity.class);
                this.finish();
                startActivity(intent_chat);
                Toast.makeText(this,"Chat",Toast.LENGTH_SHORT).show();
                break;
            case R.id.overnight_pharmacies:
                Intent intent_on= new Intent(getApplicationContext(),ActivityOvernight.class);
                this.finish();
                startActivity(intent_on);

                Toast.makeText(this,"Overnight Pharmacies",Toast.LENGTH_SHORT).show();
                break;

        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


   public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }
        switch(item.getItemId()){
            case R.id.cart:
                Toast.makeText(this, "Cart", Toast.LENGTH_SHORT).show();

                Intent intent_cart = new Intent(getApplicationContext(), Cart.class);
                startActivity(intent_cart);
                this.finish();

                break;

            case R.id.action_account:
                Toast.makeText(this,"Account",Toast.LENGTH_SHORT).show();

                AlertDialog.Builder mBuilder = new AlertDialog.Builder(MainActivity.this);
                View mView = getLayoutInflater().inflate(R.layout.activity_log_in, null);
                Button mLogin =  mView.findViewById(R.id.btnLogin);

                mLogin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(Global.a==true) {
                            Toast.makeText(MainActivity.this, "Έχετε μπει στο λογαριασμό σας", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(MainActivity.this,"You have login your account",Toast.LENGTH_SHORT).show();
                        }
                        Intent intent_profile = new Intent(getApplicationContext(),Profile.class);
                        startActivity(intent_profile);
                    }
                });

                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();

               // this.finish();
                break;

            case R.id.action_language:
                Toast.makeText(this,"Language",Toast.LENGTH_SHORT).show();
                Global.a=!Global.a;
                finish();
                startActivity(getIntent());
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    // shows the cart and the settings to the action bar
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.settings_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public void openProsfora1(){
        Product p = new Product(1,"Apivita Queen Bee Lifting Massage", 12, 10 , "Description of the Product !!!",R.drawable.prosfora1);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }
    public void openProsfora2(){
        Product p = new Product(1,"Korres", 23, 10 , "Description of the Product !!!",R.drawable.prosfora2);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }


    public void openProsfora3(){
        Product p = new Product(1,"PUPA Lipsticks", 15, 10 , "Description of the Product !!!",R.drawable.prosfora3);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }
    public void openProsfora4(){
        Product p = new Product(1,"AHAVA Hand Creams and Body Lotions", 16, 10 , "Description of the Product !!!",R.drawable.prosfora4);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }
    public void openProsfora5(){
        Product p = new Product(1,"Mustela $ NUK ", 20, 10 , "Description of the Product !!!",R.drawable.prosfora5);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }
    public void openProsfora6(){
        Product p = new Product(1,"AHAVA ", 17, 10 , "Description of the Product !!!",R.drawable.prosfora6);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }
    public void openEpoxiako1(){
        Product p = new Product(1,"Kids Sun + Nip", 19, 10 , "Description of the Product !!!",R.drawable.epoxiako1);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }
    public void openEpoxiako2(){
        Product p = new Product(1,"FrezyDerm SunScreen", 16, 10 , "Description of the Product !!!",R.drawable.epoxiako2);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }
    public void openEpoxiako3(){
        Product p = new Product(1,"APIVITA Christmas Gifts", 25, 10 , "Description of the Product !!!",R.drawable.epoxiako3);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }
    public void openEpoxiako4(){
        Product p = new Product(1,"Chicco Kids Nebulizer", 120, 10 , "Description of the Product !!!",R.drawable.epoxiako4);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }
    public void openEpoxiako5(){
        Product p = new Product(1,"Room Humidifier", 45, 10 , "Description of the Product !!!",R.drawable.epoxiako5);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }
    public void openEpoxiako6(){
        Product p = new Product(1,"Nubilizer", 120, 10 , "Description of the Product !!!",R.drawable.epoxiako6);
        Intent intent_add_product = new Intent (getApplicationContext(),AddProduct.class);
        intent_add_product.putExtra("PRODUCT INFO", new String []{p.getName(),p.getDescription()});
        intent_add_product.putExtra("PRODUCT IMAGE_PRICE",new int[]{p.getImage(),p.getPrice()});
        startActivity(intent_add_product);
    }



}
